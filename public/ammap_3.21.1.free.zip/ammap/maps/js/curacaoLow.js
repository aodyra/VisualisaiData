// (c) ammap.com | SVG (in JSON format) map of Curacao - Low
// areas: {id:"CW"}
AmCharts.maps.curacaoLow={
	"svg": {
		"defs": {
			"amcharts:ammap": {
				"projection":"mercator",
				"leftLongitude":"-69.1624547",
				"topLatitude":"12.3927182",
				"rightLongitude":"-68.73046875",
				"bottomLatitude":"12.0312619264"
			}
		},
		"g":{
			"path":[
				{
					"id":"CW",
					"title":"Curaçao",
					"d":"M799.38,641.72L722.54,555.97L620.4,415.63L304.3,318.62L0.62,0L12.97,181.18L353.47,504.67L799.38,641.72z"
				}
			]
		}
	}
};
